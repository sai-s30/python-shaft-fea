import os
import subprocess
import multiprocessing # Import to get the number of CPU cores

def generate_shaft_mesh(length=1.0, radius=0.05, element_size=None, mesh_file="output/shaft.vtk"):
    """
    Generates a tetrahedral mesh for a cylindrical shaft using Gmsh.

    Args:
        length (float): Length of the shaft.
        radius (float): Radius of the shaft.
        element_size (float, optional): Desired characteristic element size.
                                        If None, a default based on radius is used.
        mesh_file (str): Path to save the generated VTK mesh file.

    Returns:
        str: Path to the generated mesh file.
    """
    # If element_size is not provided, use default calculation based on radius
    if element_size is None:
        cl_min = radius / 3
        cl_max = radius / 2
    else:
        # Use the provided element_size for both min and max for simplicity.
        # A smaller element_size leads to a finer mesh and longer meshing time.
        # A larger element_size leads to a coarser mesh and faster meshing time,
        # but may reduce accuracy. For 0.02m, it will generate a dense mesh.
        cl_min = element_size
        cl_max = element_size * 1.5 # Allowing some variation, or just use element_size for both

    geo_code = f"""
SetFactory("OpenCASCADE");
Cylinder(1) = {{0, 0, 0, 0, 0, {length}, {radius}}};
Mesh.CharacteristicLengthMin = {cl_min};
Mesh.CharacteristicLengthMax = {cl_max};
Mesh 3; // Generate 3D mesh
"""
    os.makedirs("output", exist_ok=True)
    geo_file = "output/shaft.geo"
    with open(geo_file, "w") as f:
        f.write(geo_code)

    # Determine the number of CPU cores for parallel meshing
    # This will use all available logical cores.
    num_cores = multiprocessing.cpu_count()
    print(f"[i] Using {num_cores} CPU cores for Gmsh meshing.")

    # Construct the Gmsh command with parallelization flag
    # -3: Generate 3D mesh
    # -format vtk: Output in VTK format
    # -o {mesh_file}: Output file path
    # -nt {num_cores}: Use specified number of threads for meshing.
    # Note: While -nt is passed, Gmsh's internal algorithms may not parallelize
    # all stages (e.g., mesh reconstruction/optimization) perfectly,
    # especially for certain mesh types or versions.
    gmsh_command = ["gmsh", geo_file, "-3", "-format", "vtk", "-o", mesh_file, "-nt", str(num_cores)]

    print(f"[i] Executing Gmsh command: {' '.join(gmsh_command)}")

    try:
        # capture_output=True captures stdout/stderr, text=True decodes as text
        subprocess.run(gmsh_command, check=True, capture_output=True, text=True)
        print(f"[✓] Mesh generated at {mesh_file}")
    except subprocess.CalledProcessError as e:
        print(f"[✗] Gmsh meshing failed with return code {e.returncode}:")
        print(f"    STDOUT:\n{e.stdout}")
        print(f"    STDERR:\n{e.stderr}")
        raise RuntimeError(f"Gmsh meshing failed. Check Gmsh output above for details.") from e
    except FileNotFoundError:
        print("[✗] Error: 'gmsh' command not found.")
        print("    Please ensure Gmsh is installed and its executable is in your system's PATH.")
        raise
    return mesh_file

