import tkinter as tk
from tkinter import ttk, messagebox
from solver.fea_solver import solve_fea
import pyvista as pv
import os
import numpy as np
import time
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk

# CRITICAL: Globally prevent PyVista from exiting the Python interpreter
# This should be set once at the top level before any plotters are created.
pv.global_theme.auto_close = False

class FEAShaftGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Shaft FEA Simulator")
        # Increased height and width to accommodate graphs better
        self.geometry("1200x900") # Increased size for better graph visibility

        self.load_types = {
            "axial": ["Axial Load (N)"],
            "bending": ["Bending Load (N)"],
            "torsion": ["Torsion Load (Nm)"],
            "axial+bending": ["Axial Load (N)", "Bending Load (N)"],
            "axial+torsion": ["Axial Load (N)", "Torsion Load (Nm)"],
            "bending+torsion": ["Bending Load (N)", "Torsion Load (Nm)"],
            "axial+bending+torsion": ["Axial Load (N)", "Bending Load (N)", "Torsion Load (Nm)"]
        }

        # Initialize plot variables
        self.fig_stress_profile = None
        self.ax_stress_profile = None
        self.canvas_stress_profile = None
        self.toolbar_stress_profile = None

        self.fig_disp_profile = None
        self.ax_disp_profile = None
        self.canvas_disp_profile = None
        self.toolbar_disp_profile = None

        self.fig_stress_hist = None
        self.ax_stress_hist = None
        self.canvas_stress_hist = None
        self.toolbar_stress_hist = None

        # Animation control variables for PyVista cylinder
        self.plotter = None # This will hold the PyVista.Plotter instance for animation
        self.mesh_actor = None
        self.animation_running = False # Flag to control PyVista animation loop
        self.n_steps = 50 # Number of steps for animation (loading/unloading)
        self.animation_total_duration = 5000 # milliseconds for one full cycle (forward + backward)
        # Calculate frame delay: total duration / (steps_forward + steps_backward - 2 overlapping frames)
        self.frame_delay_ms = int(self.animation_total_duration / (2 * self.n_steps - 2)) if self.n_steps > 1 else self.animation_total_duration
        if self.frame_delay_ms <= 0: self.frame_delay_ms = 1 # Ensure at least 1ms delay

        # Data for graphs (will be populated after FEA)
        self.points_initial = None
        self.displacement_final = None
        self.von_mises_final = None
        self.total_disp_magnitude_final = None
        self.axial_coords_initial = None
        self.sorted_indices = None
        self.min_vm_overall = 0
        self.max_vm_overall = 1.0
        self.min_disp_overall = 0
        self.max_disp_overall = 1.0

        # New: Displacement Scale Factor
        # Increased default value for better visual distortion
        self.displacement_scale_factor_var = tk.StringVar(value="500.0") 


        self.create_widgets()

    def create_widgets(self):
        padding = {'padx': 10, 'pady': 5}

        # --- Input Frame ---
        input_frame = ttk.LabelFrame(self, text="Shaft Parameters & Loads")
        input_frame.grid(row=0, column=0, padx=10, pady=10, sticky='nw')

        ttk.Label(input_frame, text="Shaft Length (m):").grid(row=0, column=0, sticky='w', **padding)
        self.length_var = tk.StringVar(value="1.0")
        ttk.Entry(input_frame, textvariable=self.length_var).grid(row=0, column=1, **padding)

        ttk.Label(input_frame, text="Shaft Radius (m):").grid(row=1, column=0, sticky='w', **padding)
        self.radius_var = tk.StringVar(value="0.1")
        ttk.Entry(input_frame, textvariable=self.radius_var).grid(row=1, column=1, **padding)

        ttk.Label(input_frame, text="Young's Modulus E (Pa):").grid(row=2, column=0, sticky='w', **padding)
        self.E_var = tk.StringVar(value="2e11")
        ttk.Entry(input_frame, textvariable=self.E_var).grid(row=2, column=1, **padding)

        ttk.Label(input_frame, text="Poisson's Ratio ν:").grid(row=3, column=0, sticky='w', **padding)
        self.nu_var = tk.StringVar(value="0.3")
        ttk.Entry(input_frame, textvariable=self.nu_var).grid(row=3, column=1, **padding)

        ttk.Label(input_frame, text="Mesh Element Size (m):").grid(row=4, column=0, sticky='w', **padding)
        self.element_size_var = tk.StringVar(value="0.02")
        ttk.Entry(input_frame, textvariable=self.element_size_var).grid(row=4, column=1, **padding)

        ttk.Label(input_frame, text="Load Type:").grid(row=5, column=0, sticky='w', **padding)
        self.load_type_var = tk.StringVar()
        load_options = list(self.load_types.keys())
        self.load_type_combo = ttk.Combobox(input_frame, textvariable=self.load_type_var, values=load_options, state="readonly")
        self.load_type_combo.current(0)
        self.load_type_combo.grid(row=5, column=1, **padding)
        self.load_type_combo.bind("<<ComboboxSelected>>", self.update_load_inputs)

        self.load_inputs_frame = ttk.Frame(input_frame)
        self.load_inputs_frame.grid(row=6, column=0, columnspan=2, sticky='w', **padding)

        self.load_input_vars = {}
        self.bending_x_var = tk.StringVar(value="0.0")
        self.bending_y_var = tk.StringVar(value="0.0")
        self.update_load_inputs() # Initialize load inputs frame

        # New: Displacement Scale Factor input
        ttk.Label(input_frame, text="Disp. Scale Factor:").grid(row=7, column=0, sticky='w', **padding)
        ttk.Entry(input_frame, textvariable=self.displacement_scale_factor_var).grid(row=7, column=1, **padding)


        # --- Action Buttons ---
        button_frame = ttk.Frame(self)
        button_frame.grid(row=1, column=0, padx=10, pady=10, sticky='nw')

        self.run_button = ttk.Button(button_frame, text="Run FEA", command=self.run_fea)
        self.run_button.grid(row=0, column=0, pady=5, padx=5)

        self.visualize_button = ttk.Button(button_frame, text="Visualize Results (Static)", command=self.visualize_results, state="disabled")
        self.visualize_button.grid(row=1, column=0, pady=5, padx=5)

        self.animate_button = ttk.Button(button_frame, text="Play Looping Animation", command=self.start_animation, state="disabled")
        self.animate_button.grid(row=2, column=0, pady=5, padx=5)

        self.status_label = ttk.Label(button_frame, text="")
        self.status_label.grid(row=3, column=0, columnspan=2, pady=5)

        # --- Graph Frame ---
        self.graph_frame = ttk.LabelFrame(self, text="FEA Results Graphs") # Changed title for static graphs
        self.graph_frame.grid(row=0, column=1, rowspan=2, padx=10, pady=10, sticky='nsew')
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        
        # Configure rows within graph_frame for canvases and their toolbars
        self.graph_frame.grid_rowconfigure(0, weight=1) # Canvas 1
        self.graph_frame.grid_rowconfigure(1, weight=0) # Toolbar 1
        self.graph_frame.grid_rowconfigure(2, weight=1) # Canvas 2
        self.graph_frame.grid_rowconfigure(3, weight=0) # Toolbar 2
        self.graph_frame.grid_rowconfigure(4, weight=1) # Canvas 3
        self.graph_frame.grid_rowconfigure(5, weight=0) # Toolbar 3
        self.graph_frame.grid_columnconfigure(0, weight=1) # Single column for all


        # Graph 1: Von Mises Stress along Shaft Length
        # Reduced figsize for more minimalistic look
        self.fig_stress_profile, self.ax_stress_profile = plt.subplots(figsize=(4, 2.2), dpi=100) # Added DPI for clarity
        self.canvas_stress_profile = FigureCanvasTkAgg(self.fig_stress_profile, master=self.graph_frame)
        self.canvas_stress_profile_widget = self.canvas_stress_profile.get_tk_widget()
        # Reduced padding for tighter layout
        self.canvas_stress_profile_widget.grid(row=0, column=0, sticky='nsew', padx=1, pady=1) 

        self.toolbar_frame_stress_profile = ttk.Frame(self.graph_frame)
        self.toolbar_frame_stress_profile.grid(row=1, column=0, sticky='ew')
        self.toolbar_stress_profile = NavigationToolbar2Tk(self.canvas_stress_profile, self.toolbar_frame_stress_profile)
        self.toolbar_stress_profile.update()


        # Graph 2: Total Displacement Magnitude along Shaft Length
        # Reduced figsize for more minimalistic look
        self.fig_disp_profile, self.ax_disp_profile = plt.subplots(figsize=(4, 2.2), dpi=100) # Added DPI for clarity
        self.canvas_disp_profile = FigureCanvasTkAgg(self.fig_disp_profile, master=self.graph_frame)
        self.canvas_disp_profile_widget = self.canvas_disp_profile.get_tk_widget()
        # Reduced padding for tighter layout
        self.canvas_disp_profile_widget.grid(row=2, column=0, sticky='nsew', padx=1, pady=1) 

        self.toolbar_frame_disp_profile = ttk.Frame(self.graph_frame)
        self.toolbar_frame_disp_profile.grid(row=3, column=0, sticky='ew')
        self.toolbar_disp_profile = NavigationToolbar2Tk(self.canvas_disp_profile, self.toolbar_frame_disp_profile)
        self.toolbar_disp_profile.update()


        # Graph 3: Von Mises Stress Histogram
        # Reduced figsize for more minimalistic look
        self.fig_stress_hist, self.ax_stress_hist = plt.subplots(figsize=(4, 2.2), dpi=100) # Added DPI for clarity
        self.canvas_stress_hist = FigureCanvasTkAgg(self.fig_stress_hist, master=self.graph_frame)
        self.canvas_stress_hist_widget = self.canvas_stress_hist.get_tk_widget()
        # Reduced padding for tighter layout
        self.canvas_stress_hist_widget.grid(row=4, column=0, sticky='nsew', padx=1, pady=1) 

        self.toolbar_frame_stress_hist = ttk.Frame(self.graph_frame)
        self.toolbar_frame_stress_hist.grid(row=5, column=0, sticky='ew')
        self.toolbar_stress_hist = NavigationToolbar2Tk(self.canvas_stress_hist, self.toolbar_frame_stress_hist)
        self.toolbar_stress_hist.update()

        # Set initial blank plots
        # Reduced font sizes for minimalistic look
        self.ax_stress_profile.set_title("Von Mises Stress along Shaft Length", fontsize=9) 
        self.ax_stress_profile.set_xlabel("Axial Position (m)", fontsize=7) 
        self.ax_stress_profile.set_ylabel("Von Mises Stress (Pa)", fontsize=7) 
        self.ax_stress_profile.tick_params(axis='both', which='major', labelsize=6) 
        self.ax_stress_profile.grid(True)

        self.ax_disp_profile.set_title("Total Displacement along Shaft Length", fontsize=9)
        self.ax_disp_profile.set_xlabel("Axial Position (m)", fontsize=7)
        self.ax_disp_profile.set_ylabel("Total Displacement (m)", fontsize=7)
        self.ax_disp_profile.tick_params(axis='both', which='major', labelsize=6)
        self.ax_disp_profile.grid(True)

        self.ax_stress_hist.set_title("Von Mises Stress Histogram", fontsize=9)
        self.ax_stress_hist.set_xlabel("Von Mises Stress (Pa)", fontsize=7)
        self.ax_stress_hist.set_ylabel("Frequency", fontsize=7)
        self.ax_stress_hist.tick_params(axis='both', which='major', labelsize=6)
        self.ax_stress_hist.grid(True)
        
        # Adjust layout to prevent overlap - crucial for small figures
        self.fig_stress_profile.tight_layout(pad=0.5) # Reduced padding for tight layout
        self.fig_disp_profile.tight_layout(pad=0.5)
        self.fig_stress_hist.tight_layout(pad=0.5)


    def update_load_inputs(self, event=None):
        for widget in self.load_inputs_frame.winfo_children():
            widget.destroy()
        self.load_input_vars.clear()

        selected_load = self.load_type_var.get()
        labels = self.load_types.get(selected_load, [])

        current_row = 0
        for i, label in enumerate(labels):
            ttk.Label(self.load_inputs_frame, text=label).grid(row=current_row, column=0, sticky='w', padx=10, pady=2)
            var = tk.StringVar(value="1000.0")
            entry = ttk.Entry(self.load_inputs_frame, textvariable=var, width=15)
            entry.grid(row=current_row, column=1, padx=10, pady=2)
            self.load_input_vars[label] = var
            current_row += 1

            if "bending" in selected_load and label == "Bending Load (N)":
                ttk.Label(self.load_inputs_frame, text="Bending X-pos (m):").grid(row=current_row, column=0, sticky='w', padx=10, pady=2)
                ttk.Entry(self.load_inputs_frame, textvariable=self.bending_x_var, width=15).grid(row=current_row, column=1, padx=10, pady=2)
                current_row += 1

                ttk.Label(self.load_inputs_frame, text="Bending Y-pos (m):").grid(row=current_row, column=0, sticky='w', padx=10, pady=2)
                ttk.Entry(self.load_inputs_frame, textvariable=self.bending_y_var, width=15).grid(row=current_row, column=1, padx=10, pady=2)
                current_row += 1


    def run_fea(self):
        # Close existing PyVista plotter if open
        # We now check if self.plotter is not None before checking is_attached to avoid AttributeError
        if self.plotter:
            try:
                if hasattr(self.plotter, 'is_attached') and self.plotter.is_attached: # Robust check
                    self.plotter.close()
            except Exception as e: # Catch any other potential errors during close
                print(f"Error closing animation plotter: {e}")
            self.plotter = None
            self.mesh_actor = None
        
        # Stop any ongoing animation
        self.animation_running = False
        if hasattr(self, 'after_id'):
            self.after_cancel(self.after_id)


        try:
            params = {
                "length": float(self.length_var.get()),
                "radius": float(self.radius_var.get()),
                "E": float(self.E_var.get()),
                "nu": float(self.nu_var.get()),
                "element_size": float(self.element_size_var.get()),
                "load_type": self.load_type_var.get(),
                "load_value": {}
            }

            load_val = {"axial": 0.0, "bending": 0.0, "torsion": 0.0}
            for label, var in self.load_input_vars.items():
                val = float(var.get())
                if "Axial" in label:
                    load_val["axial"] = val
                elif "Bending" in label:
                    load_val["bending"] = val
                elif "Torsion" in label:
                    load_val["torsion"] = val

            params["load_value"] = load_val

            if "bending" in params["load_type"]:
                params["bending_pos"] = {
                    "x": float(self.bending_x_var.get()),
                    "y": float(self.bending_y_var.get())
                }
            else:
                params["bending_pos"] = {"x": 0.0, "y": 0.0}

        except ValueError:
            messagebox.showerror("Input Error", "Please enter valid numeric values.")
            return

        self.status_label.config(text="Running FEA... please wait.")
        self.update()

        try:
            solve_fea(params)
        except Exception as e:
            messagebox.showerror("Error", f"FEA simulation failed:\n{str(e)}")
            self.status_label.config(text="Simulation failed.")
            self.visualize_button.config(state="disabled")
            self.animate_button.config(state="disabled")
            return

        self.status_label.config(text="FEA completed successfully.")
        self.visualize_button.config(state="normal")
        self.animate_button.config(state="normal")
        messagebox.showinfo("Success", "FEA completed successfully!\nYou can now visualize and animate the results.")
        
        # Load the results for static graphs
        vtk_path = "output/deformed_shaft.vtk"
        if os.path.exists(vtk_path):
            mesh = pv.read(vtk_path)
            self.points_initial = mesh.points
            self.displacement_final = mesh.point_data.get("Displacement")
            self.von_mises_final = mesh.point_data.get("Von_Mises")
            self.total_disp_magnitude_final = np.linalg.norm(self.displacement_final, axis=1)

            self.min_vm_overall = 0
            self.max_vm_overall = self.von_mises_final.max() if self.von_mises_final.size > 0 else 1.0
            self.min_disp_overall = 0
            self.max_disp_overall = self.total_disp_magnitude_final.max() if self.total_disp_magnitude_final.size > 0 else 1.0

            self.axial_coords_initial = self.points_initial[:, 2]
            self.sorted_indices = np.argsort(self.axial_coords_initial)
            
            self._draw_static_graphs() # Draw static graphs after FEA

    def visualize_results(self):
        vtk_path = "output/deformed_shaft.vtk"
        if not os.path.exists(vtk_path):
            messagebox.showerror("File Not Found", f"VTK file not found at {vtk_path}. Run FEA first.")
            return

        mesh = pv.read(vtk_path)

        displacement = mesh.point_data.get("Displacement")
        if displacement is None:
            messagebox.showerror("Data Error", "Displacement data not found in VTK file.")
            return

        deformed_points = mesh.points + displacement * float(self.displacement_scale_factor_var.get()) # Apply scale factor
        deformed_mesh = mesh.copy()
        deformed_mesh.points = deformed_points

        plotter = pv.Plotter()
        # Set a callback for when this specific PyVista window is closed
        plotter.exit_callback = lambda: print("Static PyVista window closed.")
        # Relying on pv.global_theme.auto_close = False for preventing exit
        # No plotter.app.processEvents() here, as it's a static plot.

        plotter.add_mesh(deformed_mesh, scalars="Von_Mises", show_edges=True, cmap="jet")
        plotter.add_scalar_bar(title="Von Mises Stress")
        plotter.show() # This show() is blocking, which is fine for a static view

    def _draw_static_graphs(self):
        # Ensure data is available
        if self.points_initial is None or self.displacement_final is None or self.von_mises_final is None:
            # Clear graphs if no data
            self.ax_stress_profile.clear()
            self.ax_stress_profile.set_title("Von Mises Stress along Shaft Length", fontsize=9)
            self.ax_stress_profile.set_xlabel("Axial Position (m)", fontsize=7)
            self.ax_stress_profile.set_ylabel("Von Mises Stress (Pa)", fontsize=7)
            self.ax_stress_profile.grid(True)
            self.canvas_stress_profile.draw_idle()

            self.ax_disp_profile.clear()
            self.ax_disp_profile.set_title("Total Displacement along Shaft Length", fontsize=9)
            self.ax_disp_profile.set_xlabel("Axial Position (m)", fontsize=7)
            self.ax_disp_profile.set_ylabel("Total Displacement (m)", fontsize=7)
            self.ax_disp_profile.grid(True)
            self.canvas_disp_profile.draw_idle()

            self.ax_stress_hist.clear()
            self.ax_stress_hist.set_title("Von Mises Stress Histogram", fontsize=9)
            self.ax_stress_hist.set_xlabel("Von Mises Stress (Pa)", fontsize=7)
            self.ax_stress_hist.set_ylabel("Frequency", fontsize=7)
            self.ax_stress_hist.grid(True)
            self.canvas_stress_hist.draw_idle()
            self.update_idletasks()
            return # No data to plot

        # 1. Von Mises Stress along Shaft Length
        self.ax_stress_profile.clear()
        self.ax_stress_profile.plot(self.axial_coords_initial[self.sorted_indices], self.von_mises_final[self.sorted_indices], color='red')
        self.ax_stress_profile.set_title("Von Mises Stress along Shaft Length", fontsize=9)
        self.ax_stress_profile.set_xlabel("Axial Position (m)", fontsize=7)
        self.ax_stress_profile.set_ylabel("Von Mises Stress (Pa)", fontsize=7)
        self.ax_stress_profile.set_ylim(self.min_vm_overall, self.max_vm_overall * 1.05)
        self.ax_stress_profile.tick_params(axis='both', which='major', labelsize=6)
        self.ax_stress_profile.grid(True)
        self.fig_stress_profile.tight_layout(pad=0.5)
        self.canvas_stress_profile.draw_idle()
        self.canvas_stress_profile.flush_events()

        # 2. Total Displacement Magnitude along Shaft Length
        self.ax_disp_profile.clear()
        self.ax_disp_profile.plot(self.axial_coords_initial[self.sorted_indices], self.total_disp_magnitude_final[self.sorted_indices], color='blue')
        self.ax_disp_profile.set_title("Total Displacement along Shaft Length", fontsize=9)
        self.ax_disp_profile.set_xlabel("Axial Position (m)", fontsize=7)
        self.ax_disp_profile.set_ylabel("Total Displacement (m)", fontsize=7)
        self.ax_disp_profile.set_ylim(self.min_disp_overall, self.max_disp_overall * 1.05)
        self.ax_disp_profile.tick_params(axis='both', which='major', labelsize=6)
        self.ax_disp_profile.grid(True)
        self.fig_disp_profile.tight_layout(pad=0.5)
        self.canvas_disp_profile.draw_idle()
        self.canvas_disp_profile.flush_events()

        # 3. Von Mises Stress Histogram
        self.ax_stress_hist.clear()
        if self.von_mises_final.size > 0:
            self.ax_stress_hist.hist(self.von_mises_final, bins=50, density=True, color='green', alpha=0.7)
        self.ax_stress_hist.set_title("Von Mises Stress Histogram", fontsize=9)
        self.ax_stress_hist.set_xlabel("Von Mises Stress (Pa)", fontsize=7)
        self.ax_stress_hist.set_ylabel("Frequency", fontsize=7)
        self.ax_stress_hist.set_xlim(self.min_vm_overall, self.max_vm_overall * 1.05)
        self.ax_stress_hist.tick_params(axis='both', which='major', labelsize=6)
        self.ax_stress_hist.grid(True)
        self.fig_stress_hist.tight_layout(pad=0.5)
        self.canvas_stress_hist.draw_idle()
        self.canvas_stress_hist.flush_events()


    def start_animation(self):
        vtk_path = "output/deformed_shaft.vtk"
        if not os.path.exists(vtk_path):
            messagebox.showerror("File Not Found", f"VTK file not found at {vtk_path}. Run FEA first.")
            return

        mesh = pv.read(vtk_path)
        self.displacement_final = mesh.point_data.get("Displacement")
        self.von_mises_final = mesh.point_data.get("Von_Mises")

        if self.displacement_final is None or self.von_mises_final is None:
            messagebox.showerror("Data Error", "Displacement or Von Mises data missing in VTK file.")
            return

        self.points_initial = mesh.points
        self.von_mises_final = np.array(self.von_mises_final)
        self.total_disp_magnitude_final = np.linalg.norm(self.displacement_final, axis=1)

        # Determine overall min/max for consistent colormaps and plot limits
        self.min_vm_overall = 0
        self.max_vm_overall = self.von_mises_final.max() if self.von_mises_final.size > 0 else 1.0
        self.min_disp_overall = 0
        self.max_disp_overall = self.total_disp_magnitude_final.max() if self.total_disp_magnitude_final.size > 0 else 1.0

        # --- PyVista Plotter Setup ---
        # Close existing plotter if open to prevent multiple windows
        if self.plotter: # Check if plotter exists
            try:
                if hasattr(self.plotter, 'is_attached') and self.plotter.is_attached: # Robust check
                    self.plotter.close()
            except Exception as e: # Catch any other potential errors during close
                print(f"Error closing animation plotter: {e}")
            self.plotter = None
            self.mesh_actor = None
        
        self.plotter = pv.Plotter(off_screen=False, title="Shaft FEA Animation")
        # Set a callback for when the PyVista window is closed
        self.plotter.exit_callback = self._on_pyvista_close # Custom callback
        
        current_display_mesh = mesh.copy()
        current_display_mesh.points = self.points_initial
        # Ensure the scalar array name matches what's used in add_mesh
        current_display_mesh.point_data["Von_Mises"] = np.zeros_like(self.von_mises_final)

        self.mesh_actor = self.plotter.add_mesh(current_display_mesh, scalars="Von_Mises", show_edges=True, cmap="jet",
                                      clim=[self.min_vm_overall, self.max_vm_overall])
        self.plotter.add_scalar_bar(title="Von Mises Stress")
        
        # Start PyVista in non-blocking mode
        # We are relying on pv.global_theme.auto_close = False for preventing exit
        self.plotter.show(auto_close=False, interactive=False) 
        # No plotter.app.processEvents() here, relying on Tkinter's update_idletasks and PyVista's internal render loop.


        # Start the Tkinter after loop for animation
        self.current_frame_idx = 0
        self.animation_direction = 1
        self.animation_running = True # Set flag to true when animation starts
        self.after_id = self.after(self.frame_delay_ms, self._animate_cylinder)

    def _on_pyvista_close(self):
        # This function is called when the PyVista window is closed by the user
        print("PyVista window closed. Stopping animation.")
        self.animation_running = False
        if hasattr(self, 'after_id'):
            self.after_cancel(self.after_id)
        # Clean up plotter and mesh_actor references
        self.plotter = None
        self.mesh_actor = None

    def _animate_cylinder(self):
        # Check if animation is still intended to be running and plotter object exists
        # We rely on _on_pyvista_close to set self.plotter to None when its window is closed.
        if not self.animation_running or self.plotter is None:
            if hasattr(self, 'after_id'):
                self.after_cancel(self.after_id)
            return

        t = self.current_frame_idx / (self.n_steps - 1) if self.n_steps > 1 else 0.0

        # Get the displacement scale factor from the GUI input
        try:
            scale_factor = float(self.displacement_scale_factor_var.get())
        except ValueError:
            scale_factor = 1.0 # Default to 1.0 if invalid input
            print("Warning: Invalid displacement scale factor. Using 1.0.")

        # Calculate current state based on 't' and the scale factor
        current_points = self.points_initial + t * self.displacement_final * scale_factor
        current_von_mises = t * self.von_mises_final
        
        # --- Update PyVista ---
        # Get the underlying VTK data set from the actor's mapper
        current_mesh_data = self.mesh_actor.mapper.GetInput()
        current_mesh_data.points = current_points
        # Correctly update the scalar data on the mesh itself
        current_mesh_data.point_data["Von_Mises"] = current_von_mises 
        current_mesh_data.Modified() # Inform VTK that data has changed

        # No need to set active_scalars on the actor directly.
        # The mapper's input (current_mesh_data) already has the updated scalars.
        self.mesh_actor.mapper.Modified() # Inform mapper that its input has changed
        self.plotter.render() # Force a redraw
        # No plotter.app.processEvents() here, relying on Tkinter's update_idletasks for overall responsiveness.

        # Determine next frame and direction for cylinder animation
        self.current_frame_idx += self.animation_direction
        
        # Loop logic: forward, then backward, then loop
        if self.animation_direction == 1: # Moving forward
            if self.current_frame_idx >= self.n_steps:
                self.animation_direction = -1 # Change to backward
                self.current_frame_idx = self.n_steps - 2 # Adjust to avoid re-plotting max twice
                if self.current_frame_idx < 0: # Handle case where n_steps is very small (e.g., 1 or 2)
                    self.current_frame_idx = 0
        else: # Moving backward
            if self.current_frame_idx < 0:
                self.animation_direction = 1 # Change to forward
                self.current_frame_idx = 1 # Start from second frame to avoid re-plotting min twice
                if self.current_frame_idx >= self.n_steps: # Handle case where n_steps is very small (e.g., 1 or 2)
                    self.current_frame_idx = self.n_steps - 1


        # Schedule next frame
        self.after_id = self.after(self.frame_delay_ms, self._animate_cylinder)

    def on_closing(self):
        # This is for the main Tkinter GUI window closing
        # Ensure PyVista plotter is closed if it's still open
        if self.plotter:
            try:
                if hasattr(self.plotter, 'is_attached') and self.plotter.is_attached: # Robust check
                    self.plotter.close()
            except Exception as e: # Catch any other potential errors during close
                print(f"Error closing main window's animation plotter: {e}")
            self.plotter = None # Clear reference
        # Cancel any pending animation loop
        self.animation_running = False # Set flag to false
        if hasattr(self, 'after_id'):
            self.after_cancel(self.after_id)
        self.destroy() # Destroy Tkinter window


if __name__ == "__main__":
    app = FEAShaftGUI()
    app.protocol("WM_DELETE_WINDOW", app.on_closing) # Handle main Tkinter window close event
    app.mainloop()
